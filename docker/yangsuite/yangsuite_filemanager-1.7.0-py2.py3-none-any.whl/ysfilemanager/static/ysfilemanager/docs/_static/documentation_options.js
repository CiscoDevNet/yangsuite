var DOCUMENTATION_OPTIONS = {
    URL_ROOT: '',
    VERSION: '1.7.0',
    LANGUAGE: 'None',
    COLLAPSE_INDEX: false,
    FILE_SUFFIX: '.fjson',
    HAS_SOURCE: true,
    SOURCELINK_SUFFIX: '.txt'
};